/**
 * Парсинг страницы.
 * Для начала необходимо установить две библиотеки (npm i axios и npm i cheerio ): 
 * axios (используется в качестве разметки страниц html) 
 * cheerio (получение данных из html) 
*/
const axios = require('axios');
const cheerio = require('cheerio');

const parse = async() => {
    const getHTML = async(url) =>{
        const {data} = await axios.get(url);
        return cheerio.load(data);
    };
    const $ = await getHTML('https://www.elle.ru/otnosheniya/psikho/numerologiya-daty-rozhdeniya-chto-chislo-sudby-govorit-o-vashem-kharaktere/');
    const page = $('p').text();

    const fs = require('fs');
    fs.writeFile('numerology_info.txt', page, (err) => {
        if (err)
            console.log('Filenhas been saved!');
    });
};
parse();
