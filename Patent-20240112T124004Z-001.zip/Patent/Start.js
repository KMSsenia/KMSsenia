function start() {
    parse();
};

start();

