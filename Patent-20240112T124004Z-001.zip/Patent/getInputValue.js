function getInputValue() {

    // Расчет суммы введенных значений 
    inputVal = document.getElementById("myInput").value; // Выбор элемента input и получение его значения
    var birthday = inputVal.replace(/[^0-9]/g, ""); // Удаление лишних символов, оставив только числа
    birthday_String = birthday.toString();
    var sum_of_numbers = 0; // В умма введенного числа
    if (birthday != 0) {
        for (var i = 0; i <= birthday_String.length - 1; i++) { // минус 1, так как условие <=, а длина строки на 1 больше, чем максимальный индекс, т.к. подсчет накинается с нуля
            sum_of_numbers = sum_of_numbers + Number(birthday[i]); // обращаемся к цифре в строке по индексу, преобразуем в числа складываем с предыдущий результат.
        }

        sum_of_numbers_String = sum_of_numbers.toString();
        sum_of_numbers_end = Number(sum_of_numbers_String[0]) + Number(sum_of_numbers_String[1]); // Складывание оставшихся цифр

        console.log(sum_of_numbers_end); // Вывод в консоль
    }

    /**
     * Парсинг страницы.
     * Для начала необходимо установить две библиотеки (npm i axios и npm i cheerio ):
     * axios (используется в качестве разметки страниц html)
     * cheerio (получение данных из html)
    */
    import axios from 'axios';
    //const axios = require('axios');
    const cheerio = require('cheerio');
    let url = "https://www.elle.ru/otnosheniya/psikho/numerologiya-daty-rozhdeniya-chto-chislo-sudby-govorit-o-vashem-kharaktere/";
    axios.get(url).then(html => {
        const $ = cheerio.load(html.data);
        // Комируем selector из страницы
        let selector = "#app > div.app.app_ArticlesPage > main > div > div > div.articles-page__article._first-article > div.articles-wrapper._desktop > div.content-layout > article > div > section > div:nth-child(6) > div.article__block.article__block_type-text > div > div > div > p:nth-child(2)";
        let text = ""; //Переменная, которая будет хранить в себе выведенный текст
        $(selector).each((i, elem) => {
            text += '${$(elem).text()}\n';
        });
        console.log(text);
    });
}

const createPath = (page) => path.resolve(`${page}.html`);
    const createPathStyle = (page) => path.resolve(`${page}.css`);

    let basePath = '';
    let basePathStyle = '';

    switch(req.url){
        case '/':
            basePath = createPath('StartWindow');

        case '/DataInputWindow.html?':
            basePath = createPath('DataInputWindow');
            break;

        default:
            console.log('ERROR')
    }

    fs.readFile(basePath, (err, data) => {
        if (err) {
            console.log(err);
            res.end();
        }
        else{
            res.write(data); // Записывает ответ HTTP на клиент, который его запросил
            res.end();
        }
    });
    fs.readFile(basePathStyle, (err, data) => {
        if (err) {
            console.log(err);
            res.end();
        }
        else{
            res.write(data); // Записывает ответ HTTP на клиент, который его запросил
            res.end();
        }
    });