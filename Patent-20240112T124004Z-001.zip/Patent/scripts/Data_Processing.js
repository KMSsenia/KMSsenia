function getInputValue(){
    // Расчет суммы введенных значений 
    let inputVal = document.getElementById("myInput").value; // Выбор элемента input и получение его значения
    var birthday = inputVal.replace(/[^0-9]/g,""); // Удаление лишних символов, оставив только числа
    birthday_String = birthday.toString();
    var sum_of_numbers = 0; // В умма введенного числа
    if (birthday != 0) {
        for (var i = 0; i <= birthday_String.length-1; i++){ // минус 1, так как условие <=, а длина строки на 1 больше, чем максимальный индекс, т.к. подсчет накинается с нуля
            sum_of_numbers = sum_of_numbers + Number(birthday[i]); // обращаемся к цифре в строке по индексу, преобразуем в числа складываем с предыдущий результат.
        }

        sum_of_numbers_String = sum_of_numbers.toString();
        sum_of_numbers_end = Number(sum_of_numbers_String[0]) + Number(sum_of_numbers_String[1]); // Складывание оставшихся цифр

        console.log(sum_of_numbers_end); // Вывод в консоль
    }
    
  } 


