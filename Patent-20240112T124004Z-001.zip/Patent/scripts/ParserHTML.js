const axios = require('axios'); // Модуль используется в качестве разметки страниц html
const cheerio = require('cheerio'); // Модуль необходим для получение данных из html
const fs = require('fs'); 
// Парсинг страницы
const parserHTML = async() => {
    const getHTML = async(url) =>{
        const {data} = await axios.get(url);
        return cheerio.load(data);
    }
    const $ = await getHTML('https://www.elle.ru/otnosheniya/psikho/numerologiya-daty-rozhdeniya-chto-chislo-sudby-govorit-o-vashem-kharaktere/');
    const page = $('p').text();

    fs.writeFile('numerology_info.txt', page, (err) => {
        if (err)
            console.log('Filenhas been saved!');
    })
}



