module.exports = function(page) {
    var url = page.split('?')[1];
    var obj = {};
    url.split('&').forEach(function(file, ind, val) {
        var key = file.split('=')[0];
        var val = file.split('=')[1];
        obj[key] = val;
    })
    return obj
}