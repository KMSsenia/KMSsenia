const axios = require('axios'); // Модуль используется в качестве разметки страниц html
const cheerio = require('cheerio'); // Модуль необходим для получение данных из html
const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs'); // Модуль для работы с файлами 
const path = require('path'); // Модуль для формировании корректоного пути

const host = 'localhost';
const port = 8080;
const app = express();

app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
    res.sendFile(`${__dirname}/public/StartWindow.html`);
});


// Парсинг сайта
const parserHTML = async() => {
    const getHTML = async(url) =>{
        const {data} = await axios.get(url);
        return cheerio.load(data);
    }
    const $ = await getHTML('https://www.elle.ru/otnosheniya/psikho/numerologiya-daty-rozhdeniya-chto-chislo-sudby-govorit-o-vashem-kharaktere/');
    const page = $('p').text();

    fs.writeFile('./public/numerology_info.txt', page, (err) => {
        if (err)
            console.log('Filenhas been saved!');
    });
}
parserHTML();


// Обработка данных, введенных клиентом 
var urlencodedParser = bodyParser.urlencoded({extended: false}); // Парсер поможет брать все данные полученные из post запроса 
app.post('/DataInputWindow?', urlencodedParser, (req, res) => {
    if (!req.body) return res.sendStatus(404); 

    let inputText = req.body.myInput; // Введное значение клиентом
    if (inputText == "") // Проверка, если клиент ничего не отправил
        res.sendFile(`${__dirname}/public/DataInputWindow.html`);
    else
        // Расчет суммы введенных значений 
        var birthday = inputText.replace(/[^0-9]/g,""); // Удаление лишних символов, оставив только числа
        var sum_of_numbers = 0;
        if (birthday != 0) {
            for (var i = 0; i <= birthday.length-1; i++){ // минус 1, так как условие <=, а длина строки на 1 больше, чем максимальный индекс, т.к. подсчет накинается с нуля
                sum_of_numbers = sum_of_numbers + Number(birthday[i]); // обращаемся к цифре в строке по индексу, преобразуем в числа складываем с предыдущий результат.
            }

            sum_of_numbers_String = sum_of_numbers.toString();
            sum_of_numbers_end = Number(sum_of_numbers_String[0]) + Number(sum_of_numbers_String[1]); // Сложение оставшихся цифр
        }

        // Сравнение полученного числа с информацией из сайта и вывод необходимого фрагмента
        var info = fs.readFileSync('./public/numerology_info.txt').toString().split('/n'); 
        let numerology_info = '';
        let info_new = '';
        for (i in info) {
            numerology_info += info[i]; // Присваиваем содержимое файла переменной для дальнейшей обработки
        }
        switch (sum_of_numbers_end){
            case 1:
                /**
                 * Вывод информации из файла, используя метод indexOf для нахождения индексов (начало среда и конец) 
                 * и substring для возвращения необходмой подстроки
                */
                info_new = numerology_info.substring(numerology_info.indexOf("Для"),
                numerology_info.indexOf("Неспроста"));
                res.send(info_new);
                break;

            case 2:
                info_new = numerology_info.substring(numerology_info.indexOf("Неспроста"),
                numerology_info.indexOf("Те"));
                res.send(info_new);
                break;

            case 3:
                info_new = numerology_info.substring(numerology_info.indexOf("Те"),
                numerology_info.indexOf("Четверка"));
                res.send(info_new);
                break;

            case 4:
                info_new = numerology_info.substring(numerology_info.indexOf("Четверка"),
                numerology_info.indexOf("стабильные ")) + "стабильные отношения.";
                res.send(info_new);
                break;

            case 5:
                info_new = numerology_info.substring(numerology_info.indexOf("Вы"),
                numerology_info.indexOf("Шестерка"));
                res.send(info_new);
                break;

            case 6:
                info_new = numerology_info.substring(numerology_info.indexOf("Шестерка"),
                numerology_info.indexOf("Семерка"));
                res.send(info_new);
                break;

            case 7:
                info_new = numerology_info.substring(numerology_info.indexOf("Семерка"),
                numerology_info.indexOf("упустить")) + "упустить.";
                res.send(info_new);
                break;

            case 8:
                info_new = "Если вам выпала " + numerology_info.substring(numerology_info.indexOf("восьмерка"),
                numerology_info.indexOf("привязанности")) + "привязанности.";
                res.send(info_new);
                //document.querySelector('info').textContent = info_new;
                //res.render('outputWindow', {data: info_new});
                break;

            case 9:
                info_new = numerology_info.substring(numerology_info.indexOf("Под"),
                numerology_info.indexOf("Любое"));
                res.send(info_new);
                break;
        }
        res.sendFile(`${__dirname}/public/OutputWindow.html`);
        //res.render('OutputWindow', {data: info_new});
        
});

app.listen(port, host, (error) => {
     error ? console.log(error) : console.log("Слушает");
});